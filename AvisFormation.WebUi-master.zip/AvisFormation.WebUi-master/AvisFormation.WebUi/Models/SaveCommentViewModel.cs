﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AvisFormation.WebUi.Models
{
    public class SaveCommentViewModel
    {
        public string note { get;  set; }
        public string commentaire { get;  set; }
        public string nom { get; set; }
        public string nomSeo { get; set; }
    }
}