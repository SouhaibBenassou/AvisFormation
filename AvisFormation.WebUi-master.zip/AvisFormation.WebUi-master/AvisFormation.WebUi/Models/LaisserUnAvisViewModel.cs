﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AvisFormation.WebUi.Models
{
    public class LaisserUnAvisViewModel

    {
        public string FormationName { get; set; }
        public string NomSeo { get; set; }
    }
}